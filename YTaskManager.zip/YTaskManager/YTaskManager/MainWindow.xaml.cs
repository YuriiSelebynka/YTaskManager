﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace YTaskManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Task> tasksList = new List<Task>();

        public MainWindow()
        {
            InitializeComponent();
            Task t0 = new Task();
            t0.Name = "Купити молоко";
            t0.IsCompleted = false;
            t0.Description = "Description0";

            Task t1 = new Task();
            t1.Name = "Вивчити С#";
            t1.IsCompleted = false;
            t1.Description = "Description1";

            Task t2 = new Task();
            t2.Name = "Створити резюме";
            t2.IsCompleted = false;
            t2.Description = "Description2";

            tasksList.Add(t0);
            tasksList.Add(t1);
            tasksList.Add(t2);

            ToDoListBox.ItemsSource = tasksList;
            ToDoListBox.DisplayMemberPath = "Name";
        }

        private void ToDoListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Task selected = ToDoListBox.SelectedItem as Task;
            if (selected != null)
            {
                //MessageBox.Show(ToDoListBox.DisplayMemberPath = "isCompleted");
                MessageBox.Show(selected.Description);
            }
            

        }
    }
}
