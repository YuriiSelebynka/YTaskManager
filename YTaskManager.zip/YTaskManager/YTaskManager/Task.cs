﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YTaskManager
{
    internal class Task
    {
        public String Name { get; set; }
        public bool IsCompleted { get; set; }

        public String Description { get; set; }
    }
}
